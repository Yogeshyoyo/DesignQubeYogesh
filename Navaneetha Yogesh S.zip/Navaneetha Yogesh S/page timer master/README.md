## How long have I been on this page?

Ever open an email, do a task, then wonder how long that took?  Install this,
then just look at the timer next to the URL bar.  It records how long it's been
since the URL has changed.  Click to see the last few pages you were on and how
long you spent there.

All data is kept locally in ram; no data is sent over the network or saved to
disk.

Or [get it from the Chrome Web Store](https://chrome.google.com/webstore/detail/page-timer/enljfpkeopdppbphgadibdpodgjhmabm).

This is not an official Google product.
